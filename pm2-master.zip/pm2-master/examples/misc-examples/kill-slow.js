
setTimeout(function() {
  console.log('exit');
  process.exit(1);
}, 1000);
