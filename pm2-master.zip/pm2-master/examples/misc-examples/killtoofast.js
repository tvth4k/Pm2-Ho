
console.log('im a kamikazy');

setInterval(function() {
  console.log('BOUM');
  process.exit(1);
}, 30);
