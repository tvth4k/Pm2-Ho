
setTimeout(function() {
  throw new Error('New error thrown automatically');
}, 1200);
