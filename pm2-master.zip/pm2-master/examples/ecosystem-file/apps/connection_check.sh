#!/bin/bash

foo() {
    echo "Hello Bash!"
}

while true; do foo; sleep 2; done
