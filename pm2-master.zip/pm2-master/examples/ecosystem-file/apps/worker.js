
setInterval(function() {
  console.log('Worker has finished his job.');
  console.error('Worker has finished his job.');
}, 1000);
