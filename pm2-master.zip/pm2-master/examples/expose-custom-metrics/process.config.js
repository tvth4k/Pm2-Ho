module.exports = {
  apps : [{
    script : 'process-metrics.js'
  }]
}
