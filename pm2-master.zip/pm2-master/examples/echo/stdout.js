
setInterval(function() {
  process.stdout.write('ooo')
}, 100)
