throw new Error('Ugly error')
