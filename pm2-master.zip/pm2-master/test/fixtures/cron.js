
setInterval(function() {
  console.log('ok');
}, 500);
