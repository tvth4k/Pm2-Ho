
setInterval(function() {
  console.log('echo.js');
}, 500);

setInterval(function() {
  console.error('echo.js-error');
}, 500);
