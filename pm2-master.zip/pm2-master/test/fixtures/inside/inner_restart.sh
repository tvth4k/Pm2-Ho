#!/bin/bash

$PM2_PATH restart echo
$PM2_PATH restart echo
$PM2_PATH restart echo
