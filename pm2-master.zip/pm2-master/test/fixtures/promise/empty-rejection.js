
setTimeout(function() {
  Promise.reject();
}, 1000);

setInterval(function() {
}, 1000);
