
setInterval(function() {
  console.log('ok');
}, 100);

setInterval(function() {
  console.error('thisnok');
}, 100);
