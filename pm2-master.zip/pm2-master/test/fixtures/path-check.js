console.log(__filename);
console.log(module.filename);
console.log(module.parent);
console.log(module.children);
console.log(__dirname);
console.log(module);
console.log(process.env.PWD);
console.log(require.main.filename);
console.log(require.main === module);
